<?php
$dalTabletrainer = array();
$dalTabletrainer["id"] = array("type"=>20,"varname"=>"id", "name" => "id");
$dalTabletrainer["cid"] = array("type"=>3,"varname"=>"cid", "name" => "cid");
$dalTabletrainer["date"] = array("type"=>7,"varname"=>"date", "name" => "date");
$dalTabletrainer["emailid"] = array("type"=>200,"varname"=>"emailid", "name" => "emailid");
$dalTabletrainer["experience"] = array("type"=>200,"varname"=>"experience", "name" => "experience");
$dalTabletrainer["mobile"] = array("type"=>200,"varname"=>"mobile", "name" => "mobile");
$dalTabletrainer["name"] = array("type"=>200,"varname"=>"name", "name" => "name");
$dalTabletrainer["natianality"] = array("type"=>200,"varname"=>"natianality", "name" => "natianality");
$dalTabletrainer["password"] = array("type"=>200,"varname"=>"password", "name" => "password");
$dalTabletrainer["qualification"] = array("type"=>200,"varname"=>"qualification", "name" => "qualification");
$dalTabletrainer["registeredDate"] = array("type"=>7,"varname"=>"registeredDate", "name" => "registeredDate");
$dalTabletrainer["skillset"] = array("type"=>200,"varname"=>"skillset", "name" => "skillset");
$dalTabletrainer["skype"] = array("type"=>200,"varname"=>"skype", "name" => "skype");
$dalTabletrainer["username"] = array("type"=>200,"varname"=>"username", "name" => "username");
$dalTabletrainer["usertype"] = array("type"=>200,"varname"=>"usertype", "name" => "usertype");
$dalTabletrainer["whatsapp"] = array("type"=>200,"varname"=>"whatsapp", "name" => "whatsapp");
$dalTabletrainer["photo"] = array("type"=>200,"varname"=>"photo", "name" => "photo");
	$dalTabletrainer["id"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__trainer"] = &$dalTabletrainer;
?>