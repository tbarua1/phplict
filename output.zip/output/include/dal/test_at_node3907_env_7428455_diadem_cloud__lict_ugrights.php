<?php
$dalTablelict_ugrights = array();
$dalTablelict_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName");
$dalTablelict_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTablelict_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask");
	$dalTablelict_ugrights["TableName"]["key"]=true;
	$dalTablelict_ugrights["GroupID"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__lict_ugrights"] = &$dalTablelict_ugrights;
?>