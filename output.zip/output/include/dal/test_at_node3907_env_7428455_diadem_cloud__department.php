<?php
$dalTabledepartment = array();
$dalTabledepartment["Department_id"] = array("type"=>3,"varname"=>"Department_id", "name" => "Department_id");
$dalTabledepartment["Dname"] = array("type"=>200,"varname"=>"Dname", "name" => "Dname");
	$dalTabledepartment["Department_id"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__department"] = &$dalTabledepartment;
?>