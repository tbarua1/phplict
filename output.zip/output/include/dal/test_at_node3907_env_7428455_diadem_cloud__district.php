<?php
$dalTabledistrict = array();
$dalTabledistrict["did"] = array("type"=>3,"varname"=>"did", "name" => "did");
$dalTabledistrict["division_id"] = array("type"=>3,"varname"=>"division_id", "name" => "division_id");
$dalTabledistrict["dname"] = array("type"=>200,"varname"=>"dname", "name" => "dname");
	$dalTabledistrict["did"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__district"] = &$dalTabledistrict;
?>