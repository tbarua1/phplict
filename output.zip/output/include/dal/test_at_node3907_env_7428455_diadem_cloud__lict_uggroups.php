<?php
$dalTablelict_uggroups = array();
$dalTablelict_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTablelict_uggroups["Label"] = array("type"=>200,"varname"=>"Label", "name" => "Label");
	$dalTablelict_uggroups["GroupID"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__lict_uggroups"] = &$dalTablelict_uggroups;
?>