<?php
$dalTablefull_batch_details = array();
$dalTablefull_batch_details["track"] = array("type"=>3,"varname"=>"track", "name" => "track");
$dalTablefull_batch_details["Batchcode"] = array("type"=>3,"varname"=>"Batchcode", "name" => "Batchcode");
$dalTablefull_batch_details["fbgroup"] = array("type"=>3,"varname"=>"fbgroup", "name" => "fbgroup");
$dalTablefull_batch_details["university_id"] = array("type"=>3,"varname"=>"university_id", "name" => "university_id");
$dalTablefull_batch_details["division_id"] = array("type"=>3,"varname"=>"division_id", "name" => "division_id");
$dalTablefull_batch_details["department_id"] = array("type"=>3,"varname"=>"department_id", "name" => "department_id");
$dalTablefull_batch_details["uni_spoc_name"] = array("type"=>3,"varname"=>"uni_spoc_name", "name" => "uni_spoc_name");
$dalTablefull_batch_details["uni_spoc_contact"] = array("type"=>3,"varname"=>"uni_spoc_contact", "name" => "uni_spoc_contact");
$dalTablefull_batch_details["ey_spoc"] = array("type"=>3,"varname"=>"ey_spoc", "name" => "ey_spoc");
$dalTablefull_batch_details["local_spoc"] = array("type"=>3,"varname"=>"local_spoc", "name" => "local_spoc");
$dalTablefull_batch_details["cid"] = array("type"=>3,"varname"=>"cid", "name" => "cid");
$dalTablefull_batch_details["schedule"] = array("type"=>3,"varname"=>"schedule", "name" => "schedule");
$dalTablefull_batch_details["tech_trainer"] = array("type"=>3,"varname"=>"tech_trainer", "name" => "tech_trainer");
$dalTablefull_batch_details["soft_skill_trainer"] = array("type"=>3,"varname"=>"soft_skill_trainer", "name" => "soft_skill_trainer");
$dalTablefull_batch_details["sdate"] = array("type"=>3,"varname"=>"sdate", "name" => "sdate");
$dalTablefull_batch_details["stime"] = array("type"=>3,"varname"=>"stime", "name" => "stime");
$dalTablefull_batch_details["etime"] = array("type"=>3,"varname"=>"etime", "name" => "etime");
$dalTablefull_batch_details["status"] = array("type"=>3,"varname"=>"status", "name" => "status");
$dalTablefull_batch_details["remark"] = array("type"=>3,"varname"=>"remark", "name" => "remark");

$dal_info["test_at_node3907_env_7428455_diadem_cloud__full_batch_details"] = &$dalTablefull_batch_details;
?>