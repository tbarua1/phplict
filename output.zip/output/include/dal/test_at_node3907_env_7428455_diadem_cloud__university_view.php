<?php
$dalTableuniversity_view = array();
$dalTableuniversity_view["university_id"] = array("type"=>3,"varname"=>"university_id", "name" => "university_id");
$dalTableuniversity_view["University_name"] = array("type"=>200,"varname"=>"University_name", "name" => "University_name");
$dalTableuniversity_view["division_id"] = array("type"=>3,"varname"=>"division_id", "name" => "division_id");
$dalTableuniversity_view["dname"] = array("type"=>200,"varname"=>"dname", "name" => "dname");

$dal_info["test_at_node3907_env_7428455_diadem_cloud__university_view"] = &$dalTableuniversity_view;
?>