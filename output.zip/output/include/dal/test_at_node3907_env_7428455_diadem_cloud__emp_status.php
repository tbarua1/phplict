<?php
$dalTableemp_status = array();
$dalTableemp_status["status_id"] = array("type"=>3,"varname"=>"status_id", "name" => "status_id");
$dalTableemp_status["status"] = array("type"=>200,"varname"=>"status", "name" => "status");
	$dalTableemp_status["status_id"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__emp_status"] = &$dalTableemp_status;
?>