<?php
$dalTableproject1_audit = array();
$dalTableproject1_audit["id"] = array("type"=>3,"varname"=>"id", "name" => "id");
$dalTableproject1_audit["datetime"] = array("type"=>135,"varname"=>"datetime", "name" => "datetime");
$dalTableproject1_audit["ip"] = array("type"=>200,"varname"=>"ip", "name" => "ip");
$dalTableproject1_audit["user"] = array("type"=>200,"varname"=>"user", "name" => "user");
$dalTableproject1_audit["table"] = array("type"=>200,"varname"=>"table", "name" => "table");
$dalTableproject1_audit["action"] = array("type"=>200,"varname"=>"action", "name" => "action");
$dalTableproject1_audit["description"] = array("type"=>201,"varname"=>"description", "name" => "description");
	$dalTableproject1_audit["id"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__project1_audit"] = &$dalTableproject1_audit;
?>