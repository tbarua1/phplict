<?php
$dalTableschedule_map = array();
$dalTableschedule_map["track"] = array("type"=>3,"varname"=>"track", "name" => "track");
$dalTableschedule_map["Batchcode"] = array("type"=>3,"varname"=>"Batchcode", "name" => "Batchcode");
$dalTableschedule_map["fbgroup"] = array("type"=>3,"varname"=>"fbgroup", "name" => "fbgroup");
$dalTableschedule_map["university_id"] = array("type"=>3,"varname"=>"university_id", "name" => "university_id");
$dalTableschedule_map["Date"] = array("type"=>3,"varname"=>"Date", "name" => "Date");
$dalTableschedule_map["status"] = array("type"=>3,"varname"=>"status", "name" => "status");
$dalTableschedule_map["University_name"] = array("type"=>3,"varname"=>"University_name", "name" => "University_name");
$dalTableschedule_map["Lat"] = array("type"=>3,"varname"=>"Lat", "name" => "Lat");
$dalTableschedule_map["Lng"] = array("type"=>3,"varname"=>"Lng", "name" => "Lng");

$dal_info["test_at_node3907_env_7428455_diadem_cloud__schedule_map"] = &$dalTableschedule_map;
?>