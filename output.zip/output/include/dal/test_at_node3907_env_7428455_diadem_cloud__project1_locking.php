<?php
$dalTableproject1_locking = array();
$dalTableproject1_locking["id"] = array("type"=>3,"varname"=>"id", "name" => "id");
$dalTableproject1_locking["table"] = array("type"=>200,"varname"=>"table", "name" => "table");
$dalTableproject1_locking["startdatetime"] = array("type"=>135,"varname"=>"startdatetime", "name" => "startdatetime");
$dalTableproject1_locking["confirmdatetime"] = array("type"=>135,"varname"=>"confirmdatetime", "name" => "confirmdatetime");
$dalTableproject1_locking["keys"] = array("type"=>200,"varname"=>"keys", "name" => "keys");
$dalTableproject1_locking["sessionid"] = array("type"=>200,"varname"=>"sessionid", "name" => "sessionid");
$dalTableproject1_locking["userid"] = array("type"=>200,"varname"=>"userid", "name" => "userid");
$dalTableproject1_locking["action"] = array("type"=>3,"varname"=>"action", "name" => "action");
	$dalTableproject1_locking["id"]["key"]=true;

$dal_info["test_at_node3907_env_7428455_diadem_cloud__project1_locking"] = &$dalTableproject1_locking;
?>